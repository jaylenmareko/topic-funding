<?php

// File generated from our OpenAPI spec

namespace Stripe\EventData;

/**
 * @property string $transaction_id The transaction ID of the received credit.
 */
class V2MoneyManagementReceivedCreditAvailableEventData extends \Stripe\StripeObject {}
