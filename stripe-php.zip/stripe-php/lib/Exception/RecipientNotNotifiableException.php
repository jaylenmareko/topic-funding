<?php

// File generated from our OpenAPI spec

namespace Stripe\Exception;

class RecipientNotNotifiableException extends ApiErrorException {}
