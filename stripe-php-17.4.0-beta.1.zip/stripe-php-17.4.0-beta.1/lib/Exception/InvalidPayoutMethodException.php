<?php

// File generated from our OpenAPI spec

namespace Stripe\Exception;

class InvalidPayoutMethodException extends ApiErrorException {}
